[
  {
    value: null,
    code: null,
    text: "กรุณาเลือกธนาคาร"
  },
  {
    value: "KBZpay",
    code: "KBZpay",
    text: "KBZpay"
  },

  {
    value: "WAVEPAY",
    code: "WAVEPAY",
    text: "WAVEPAY"
  },
  {
    value: "KBANK",
    code: "KBANK",
    text: "KBANK"
  },
  {
    value: "TRUEWALLET",
    code: "TRUEWALLET",
    text: "ทรูวอลเล็ต"
  },
  {
    value: "TMB",
    code: "TMB",
    text: "TTB"
  },
  {
    value: "BBL",
    code: "BBL",
    text: "ธนาคารกรุงเทพ"
  },
  {
    value: "KTB",
    code: "KTB",
    text: "ธนาคารกรุงไทย"
  },
  {
    value: "BAY",
    code: "BAY",
    text: "ธนาคารกรุงศรีอยุธยา"
  },
  {
    value: "KKP",
    code: "KKP",
    text: "ธนาคารเกียรตินาคินภัทร"
  },
  {
    value: "CIMB",
    code: "CIMB",
    text: "ธนาคารซีไอเอ็มบีไทย"
  },
  {
    value: "TISCO",
    code: "TISCO",
    text: "ธนาคารทิสโก้"
  },
  {
    value: "TBANK",
    code: "TBANK",
    text: "ธนาคารธนชาต"
  },
  {
    value: "UOBT",
    code: "UOBT",
    text: "ธนาคารยูโอบี"
  },
  {
    value: "TCD",
    code: "TCD",
    text: "ธนาคารไทยเครดิตเพื่อรายย่อย"
  },
  {
    value: "LHFG",
    code: "LHFG",
    text: "ธนาคารแลนด์แอนด์ เฮ้าส์"
  },
  {
    value: "BAAC",
    code: "BAAC",
    text: "ธนาคารเพื่อการเกษตรและสหกรณ์การเกษตร"
  },
  {
    value: "GSB",
    code: "GSB",
    text: "ธนาคารออมสิน"
  },
  {
    value: "GHB",
    code: "GHB",
    text: "ธนาคารอาคารสงเคราะห์"
  },
  {
    value: "ISBT",
    code: "ISBT",
    text: "ธนาคารอิสลามแห่งประเทศไทย"
  },
  {
    value: "SCB",
    code: "SCB",
    text: "ธนาคารไทยพานิชย์"
  }
];
